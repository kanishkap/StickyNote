package Servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Dao;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session= request.getSession();
		String email=request.getParameter("username");
		String password=request.getParameter("password");
		String page=" ";
		System.out.println(email+" "+password);
			
		if(email.equals("") || password.equals(""))
		{
			page="error.jsp?msg=can'tnull";
		}
		else
		{	System.out.println("else part");
		//seckey = Encryption.encrypt(password+email);
			String key="select * from register where email='"+email+"' and pass='"+password+"'";
			
			
			ResultSet rs;
			try {
				rs = Dao.select(key);
			 
			if(rs.next())
			{		
				session.setAttribute("email", email);
				//session.setAttribute("password", seckey);
				//System.out.println("session value");
				System.out.println(session.getAttribute("email"));
				
				//session.setMaxInactiveInterval(30);
				page="MyNote.jsp";	
			}
			else
			{
				System.out.println("error");
			}
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
		}
		response.sendRedirect(page);

	}

}
