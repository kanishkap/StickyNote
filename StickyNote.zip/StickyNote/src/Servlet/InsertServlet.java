package Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*response.getWriter().println(request.getParameter("start_date"));
		response.getWriter().println(request.getParameter("end_date"));
		response.getWriter().println(request.getParameter("status"));*/
		
		String start_date=request.getParameter("start_date");
		String end_date=request.getParameter("end_date");
		String status=request.getParameter("status");
		String message=request.getParameter("message");
		String page1="";
		



		try
		{	HttpSession session=request.getSession();
			System.out.println("into connection");
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","root");
			PreparedStatement ps=conn.prepareStatement("insert into sticky"+((String) session.getAttribute("email")).split("@")[0]+"(start_date,end_date,status,message) values ('"+start_date+"','"+end_date+"','"+status+"','"+message+"')");
			int i=ps.executeUpdate();
			//resultset is an interface an it behvae like an aary but it srore any types of data

			if(i!=0)
			{
				page1="StickyNote.jsp?msg=success";
			}
			else
			{
				page1="error.jsp?msg=failed";
			}
}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
