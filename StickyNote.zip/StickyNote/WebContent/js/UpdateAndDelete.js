function Delete_Button_Call(Sid) {	
	$.post("http://localhost:8080/StickyNote/DeleteServlet", {
		sid : Sid	
	
	} );
}

function Update_Button_Call(Sid,start,end,Status,msg) {
	var startDateVal=$('#'+ start).val();
	var endDateVal=$('#'+ end).val();
	//var statusVal=$('#'+"input[name='status']:checked").val();
	var statusVal=$('#'+ Status).val();
	var messageVal=$('#'+ msg).val();
	$.post("http://localhost:8080/StickyNote/UpdateServlet", {
		sid : Sid,
		start_date : startDateVal,
		end_date :endDateVal, 
		status : statusVal,
		message : messageVal

	}
	/*function(result) {
		$('#message').html(result); // message you want to show
	}*/);
}